<?php
ob_start();
session_start();
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Miroslava Koleva</title>

    <!-- Main style -->
    <link type="text/css" rel="stylesheet" href="style.css">
</head>
<body>
<!-- MAIN CONTAINER -->
<div id="container">
    <header>
        <div id="top_nav" >
            <?php
            if(empty($_SESSION['id'])) {
                ?>
                <ul id="top_navigation" class="clearfix">
                    <li><a href="registration.php">Регистрация</a></li>
                    <li><a href="log_in.php">Вход</a></li>
                </ul>
                <?php
            } else {
                echo "Здравей, ".$_SESSION['first_name']." ".$_SESSION['last_name'];
            }
            ?>
        </div>
    </header>
    <div id="main_content" class="clearfix">
        <?php
        if(!empty($_SESSION['id'])) {
            ?>
            <div id="left">
                <nav>
                    <ul id="nav">
                        <li><a href="upload_file.php">Качи реферат</a></li>
                        <li><a href="users.php">Потребители</a></li>
                        <li><a href="files_history.php">История на рефератите</a></li>
                        <li><a href='log_out.php'>Изход</a></li>
                    </ul>
                </nav>
            </div>
            <?php
        }
        ?>
        <div id="right">
            <div id="content">
            <h1>Качване на реферат</h1>
            <div id="commentTextarea">
                <form method="post" action="requests/upload.request.php" enctype="multipart/form-data">
                    <input type="text" name="name" placeholder="Име на файла" />
                    <input type="file" name="file" />
                    <textarea name="description" placeholder="Добаявне на коментар..."></textarea>
                    <div class="buttons">
                        <button class="active_button">Качване на реферата</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- END MAIN CONTAINER -->
</body>
</html>