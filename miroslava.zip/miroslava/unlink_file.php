<?php
require_once("classes/User.php");
echo $_GET['url'];
unlink($_GET['url']);
$userObj = new User();
$userObj->delete_file($_GET['file_id']);

header("Location: files_history.php");