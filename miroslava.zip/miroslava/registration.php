<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />

    <title>Miroslava</title>

    <link rel="stylesheet" type="text/css" href="style_registration.css" />
</head>
<body>

<div id="container">
    <div id="container_title">
        <h1>Регистрация</h1>
    </div>

    <div id="container_content">
        <div id="container_form">
            <form method="post" action="requests/registration.request.php">
                <input type="email" name="email" placeholder="E-mail" />
                <input type="text" name="name" placeholder="Име" />
                <input type="text" name="last_name" placeholder="Фамилия" />
                <input type="password" name="pass" placeholder="Парола" />
                <input type="password" name="rpass" placeholder="Повтори паролата" />

                <button name="submit">Регистрация</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>
