<?php
ob_start();
session_start();
class User
{

    public $db; //  mysqli


    public function __construct() {
        $this->db = new mysqli("localhost", "root", "", "portal");
        $this->db->set_charset("utf8");
    }

   public function insert_user($email, $name, $lastName, $pass, $rpass) {
        if(!empty($email) && $email != NULL && filter_var($email, FILTER_VALIDATE_EMAIL)) {
            if($name != NULL && strlen($name) >= 3 && $lastName != NULL && strlen($lastName) >= 3) {
                if($pass != NULL && strlen($pass) > 5 && $pass == $rpass) {
                    $hash = sha1($pass);
                    $sql = "SELECT `email` FROM `users` WHERE `email` = '$email'";
                    $q = $this->db->query($sql);
                    if($q->num_rows < 1) {
                        $sql = "INSERT INTO `users` (first_name, last_name, email, password, created_at) VALUES ('$name', '$lastName', '$email', '$hash', NOW())";
                        if($this->db->query($sql)) {
                            $sql = "SELECT * FROM `users` ORDER BY `id` DESC LIMIT 1";
                            $q = $this->db->query($sql);
                            $result = $q->fetch_assoc();
                            foreach($result as $key => $val) {
                                $_SESSION[$key] = $val;
                            }
                            header("Location: ../index.php");
                        } else {
                            return $sql."<br />".$this->db->error;
                        }
                    } else {
                        return "Потребителското име вече е заето!";
                    }
                } else {
                    return "Паролата е прекаленно кратко или не съответства на повторената парола!";
                }
            } else {
                return "Имената са прекаленно кратки или е празни!";
            }
        } else {
            return "Невалидна ел. поща!";
        }
   }

    public function log_in($email, $pass) {
        $hash = sha1($pass);
        $sql = "SELECT * FROM `users` WHERE `email` = '$email' AND `password` = '$hash'";
        $q = $this->db->query($sql);
        if($q && $q->num_rows > 0) {
            $result = $q->fetch_assoc();
            foreach($result as $key => $val) {
                $_SESSION[$key] = $val;
            }
            header("Location: ../index.php");
        } else {
            header("Location: ../log_in.php");
        }
    }

    public function get_all() {
        $sql = "SELECT * FROM `users` ORDER BY `id` DESC";
        $q = $this->db->query($sql);
        return $q->fetch_all(1);
    }

    private function random_string() {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < 10; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function upload_file($userID, $fileName, $fileDescription, $file) {
        $target_dir = "../files/";
        
        $target_file = $target_dir . basename($file["file"]["name"]);
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        $newName = $this->random_string().".".$imageFileType;
        $target_file = $target_dir.$newName;

        $uploadOk = 1;

        if (file_exists($target_file)) {
            return "Файлът вече съществува!";
            $uploadOk = 0;
        }

        if ($file["file"]["size"] > 500000) {
            return "Прекалено голям файл!";
            $uploadOk = 0;
        }

        if($imageFileType != "zip" && $imageFileType != "pdf" && $imageFileType != "doc" ) {
            return "Позволените размери са само zip, pdf, doc";
            $uploadOk = 0;
        }

        if ($uploadOk == 0) {
            return "Файлът не беше качен!";

        } else {
            if (move_uploaded_file($file["file"]["tmp_name"], $target_file)) {
                echo "Файлът \"". $fileName . "\" беше качен успешно.";
                $sql = "INSERT INTO `files` (`user_id`, `name`, `description`, `path`, `created_at`) VALUES ('$userID', '$fileName', '$fileDescription', '$target_file', NOW())";
                if($this->db->query($sql)) {
                    header("Location: ../files_history.php");
                } else {
                    echo "Възникна грешка, моля свържете се с администратора на сайта!";
                }
            } else {
                echo "Неуспешно качване на файла!";
            }
        }
    }

    public function get_all_files($userID) {
        $sql = "SELECT * FROM `files` WHERE `user_id` = '$userID' ORDER BY `id` DESC";
        $q = $this->db->query($sql);
        if($q && $q->num_rows >= 1) {
            return $q->fetch_all(1);
        } else {
            return null;
        }
    }

    public function delete_file($fileID) {
        $sql = "DELETE FROM `files` WHERE `id` = '$fileID'";
        return $this->db->query($sql) ? true : false;
    }

    public function get_file_information($fileID) {
        $sql = "SELECT * FROM `files` WHERE `id` = '{$fileID}'";
        $q = $this->db->query($sql);
        if($q && $q->num_rows >= 1) {
            return $q->fetch_assoc();
        }
    }

    public function add_comment($userID, $fileID, $comment) {
        $sql = "INSERT INTO `comments` (`user_id`, `file_id`, `content`, `created_at`) VALUES ('$userID', '$fileID', '$comment', NOW())";
        if($this->db->query($sql)) {
            header("Location: ../each_file.php?file_id=$fileID");
        } else {
            $this->db->error;
        }
    }

    public function get_comments($fileID) {
        $sql = "SELECT * FROM `comments` WHERE `file_id` = '$fileID' ORDER BY `id` DESC";
        $q = $this->db->query($sql);
        if($q && $q->num_rows >= 1) {
            return $q->fetch_all(1);
        } else {
            return null;
        }
    }

    public function get_user_by_id($userID) {
        $sql = "SELECT * FROM `users` WHERE `id` = '$userID'";
        $q = $this->db->query($sql);
        if($q && $q->num_rows >= 1) {
            $name = $q->fetch_assoc();
            return $name['first_name']." ".$name['last_name'];
        } else {
            return null;
        }
    }

    public function rate($userID, $fileID, $rate) {
        $sql = "SELECT * FROM `rating` WHERE `user_id` = '$userID' AND `file_id` = '$fileID'";
        $q = $this->db->query($sql);
        if($q->num_rows >= 1) {
            $sql = "UPDATE `rating` SET `rate` = '$rate' WHERE `user_id` = '$userID' AND `file_id` = '$fileID'";
            $this->db->query($sql);
            return "Успешно обновена оценка!";
        } else {
            $sql = "INSERT INTO `rating` (`user_id`, `file_id`, `rate`) VALUES ('$userID', '$fileID', '$rate')";
            $this->db->query($sql) or die($this->db->error);
            return "Успешно дадена оценка!";
        }
    }

    public function get_rating($fileID) {
        $sql = "SELECT SUM(rate) as sum_of, COUNT(`id`) as count_of FROM `rating` WHERE `file_id` = '$fileID'";
        $q = $this->db->query($sql);
        if($q && $q->num_rows >= 1) {
            $r = $q->fetch_assoc();
            return $r['sum_of'] / $r['count_of'];
        }

    }
}