<?php
error_reporting(0);
ob_start();
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Miroslava Koleva</title>

    <!-- Main style -->
    <link type="text/css" rel="stylesheet" href="style.css">
</head>
<body>
<!-- MAIN CONTAINER -->
<div id="container">
    <header>
        <div id="top_nav" >
            <?php
            if(empty($_SESSION['id'])) {
                ?>
                <ul id="top_navigation" class="clearfix">
                    <li><a href="registration.php">Регистрация</a></li>
                    <li><a href="log_in.php">Вход</a></li>
                </ul>
                <?php
            } else {
                echo "Здравей, ".$_SESSION['first_name']." ".$_SESSION['last_name'];
            }
            ?>
        </div>
    </header>
    <div id="main_content" class="clearfix">
        <?php
        if(!empty($_SESSION['id'])) {
            ?>
            <div id="left">
                <nav>
                    <ul id="nav">
                        <li><a href="upload_file.php">Качи реферат</a></li>
                        <li><a href="users.php">Потребители</a></li>
                        <li><a href="files_history.php">История на рефератите</a></li>
                        <li><a href='log_out.php'>Изход</a></li>
                    </ul>
                </nav>
            </div>
            <?php
        }
        ?>
        <div id="right">
            <div id="comment_section">
                <h3>Потребители</h3>
                <?php
                require_once("classes/User.php");
                $userObj = new User();
                if($_GET['user_id'] != null) {
                    $userID = $_GET['user_id'];
                } else {
                    $userID = $_SESSION['id'];
                }
                if($userObj->get_all_files($userID) != null) {
                    foreach($userObj->get_all_files($userID) as $file):
                        ?>
                        <div class="comment">
                            <div class="comment_title">
                                <span class="name"><a href="each_file.php?file_id=<?=$file['id']?>"><?=$file['name']?></a></span>
                                <span class="date">Регистриран на: <?=$file['created_at']?></span>
                            </div>
                            <p><?=$file['description'];?></p>
                            <?php
                                if($_GET['user_id'] == $_SESSION['id']) { ?>
                            <p><a href="unlink_file.php?url=<?= "./".substr($file['path'], 3) ?>&file_id=<?=$file['id']?>">Изтрий файла!</a></p>
                                    <?php } ?>
                        </div>
                        <?php
                    endforeach;
                }
                ?>
            </div>
        </div>
    </div>
</div>
<!-- END MAIN CONTAINER -->
</body>
</html>