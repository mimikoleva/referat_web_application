<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />

    <title>Miroslava</title>

    <link rel="stylesheet" type="text/css" href="style_registration.css" />
</head>
<body>

<div id="container">
    <div id="container_title">
        <h1>Вход</h1>
    </div>

    <div id="container_content">
        <div id="container_form">
            <form method="post" action="requests/log_in.request.php">
                <input type="email" name="email" placeholder="E-mail" />
                <input type="password" name="pass" placeholder="Парола" />

                <button name="submit">Вход</button>
                <a href="registration.php">Регистрация!</a>
                <div style="width: 100%; height: 10px; display: block;"></div>
            </form>
        </div>
    </div>
</div>

</body>
</html>
