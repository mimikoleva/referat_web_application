<?php
require_once("../classes/User.php");

$userObj = new User();

echo $userObj->add_comment($_SESSION['id'], $_GET['file_id'], $_POST['content']);