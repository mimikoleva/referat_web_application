<?php
require_once("../classes/User.php");

$userObj = new User();
echo $userObj->upload_file($_SESSION['id'], $_POST['name'], $_POST['description'], $_FILES);