<?php
require_once("../classes/User.php");

$userObj = new User();

echo $userObj->log_in($_POST['email'], $_POST['pass']);