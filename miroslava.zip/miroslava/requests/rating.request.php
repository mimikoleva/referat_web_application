<?php
require_once("../classes/User.php");
//echo $_POST['rating']." - ".$_POST['file_id'];
print_r($_SESSION);
$userObj = new User();
echo $userObj->rate($_SESSION['id'], $_POST['file_id'], $_POST['rating']);