<?php
require_once("../classes/User.php");

$userObj = new User();

echo $userObj->insert_user($_POST['email'], $_POST['name'], $_POST['last_name'], $_POST['pass'], $_POST['rpass']);