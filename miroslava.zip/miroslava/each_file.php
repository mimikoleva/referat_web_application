<?php
ob_start();
session_start();
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Miroslava Koleva</title>
    <script src="https://code.jquery.com/jquery-2.2.0.min.js"></script>
    <!-- Main style -->
    <link type="text/css" rel="stylesheet" href="style.css">
</head>
<body>
<!-- MAIN CONTAINER -->
<div id="container">
    <header>
        <div id="top_nav" >
            <?php
            if(empty($_SESSION['id'])) {
                ?>
                <ul id="top_navigation" class="clearfix">
                    <li><a href="registration.php">Регистрация</a></li>
                    <li><a href="log_in.php">Вход</a></li>
                </ul>
                <?php
            } else {
                echo "Здравей, ".$_SESSION['first_name']." ".$_SESSION['last_name'];
            }
            ?>
        </div>
    </header>
    <div id="main_content" class="clearfix">
        <?php
        if(!empty($_SESSION['id'])) {
            ?>
            <div id="left">
                <nav>
                    <ul id="nav">
                        <li><a href="upload_file.php">Качи реферат</a></li>
                        <li><a href="users.php">Потребители</a></li>
                        <li><a href="files_history.php">История на рефератите</a></li>
                        <li><a href='log_out.php'>Изход</a></li>
                    </ul>
                </nav>
            </div>
            <?php
        }
        ?>
        <div id="right">
            <div id="content">
                <?php
                    require_once("classes/User.php");
                    $userObj = new User();
                    $file = $userObj->get_file_information($_GET['file_id']);
                    $rating = ceil($userObj->get_rating($_GET['file_id']));
                    if($rating > 5)
                        $rating = 5;
                ?>
                <h1><?=$file['name']?></h1>
                <p style="margin: 10px 0px 0px 0px;">
                <span class="star-rating">
                    <input type="radio" name="rating" <?php if($rating == 1) echo "checked"; ?> value="1"><i></i>
                    <input type="radio" name="rating" <?php if($rating == 2) echo "checked"; ?>  value="2"><i></i>
                    <input type="radio" name="rating" <?php if($rating == 3) echo "checked"; ?>  value="3"><i></i>
                    <input type="radio" name="rating" <?php if($rating == 4) echo "checked"; ?>  value="4"><i></i>
                    <input type="radio" name="rating" <?php if($rating == 5) echo "checked"; ?>  value="5"><i></i>
                </span>
                </p>
                <p style="margin: 20px 0px 0px 0px;">
                    <?=$file['description']?>
                </p>
                <p>
                    <a target="_blank" href="<?= "./".substr($file['path'], 3) ?>">Свали файла</a></span>
                </p>
                <h1>Коментари</h1>
                <div id="commentTextarea" style="margin: 10px 0px 0px 0px;">
                    <form method="post" action="requests/post_comment.request.php?file_id=<?=$file['id']?>">
                        <textarea name="content" placeholder="Добаявне на коментар..."></textarea>
                        <div class="buttons">
                            <button class="active_button">Изпрати</button>
                        </div>
                    </form>
                </div>
                <?php
                    if($userObj->get_comments($_GET['file_id']) != null) {
                    foreach($userObj->get_comments($_GET['file_id']) as $comment):
                    ?>
                    <div class="comment" style="margin: 30px 0px 0px 0px;">
                        <div class="comment_title">
                            <span class="name"><?=$userObj->get_user_by_id($comment['user_id'])?></span>
                            <span class="date">Написан на: <?=$comment['created_at']?></span>
                        </div>
                        <p><?=$comment['content']?></p>
                    </div>
                <?php
                endforeach;
                }
                ?>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTAINER -->
    <script>
        $(':radio').change(
            function(){
                var rating =  $(this).val();
                var file_id = '<?=$_GET['file_id']; ?>';

                $.post( "requests/rating.request.php", { rating: rating, file_id: file_id }, function(result) { alert (result); location.reload();   } );
            }
        )
    </script>
</body>
</html>